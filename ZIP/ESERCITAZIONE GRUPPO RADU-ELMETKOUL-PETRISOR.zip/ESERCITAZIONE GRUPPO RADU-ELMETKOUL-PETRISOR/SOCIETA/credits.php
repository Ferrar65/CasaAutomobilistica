<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="UTF-8">
      <title>SOCIETA AUTOMOBILISTICA </title>
      <link rel="stylesheet" href="css/bootstrap.min.css">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta http-equiv="X-UA-Compatible" content="ie=edge">
      <title>Document</title>
   </head>
   <body>
      <html>
         <head>
            <title>Il Gioco dell'SOCIETA</title>
            <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
            <link href="css/style.css" rel="stylesheet">
         </head>
         <body>

           <nav class="navbar navbar-expand-md navbar-dark bg-dark">
             <div class="container-fluid">
               <div class="navbar-collapse collapse w-100 order-1 order-md-0 dual-collapse2">
                 <ul class="navbar-nav me-auto">
                   <li class="nav-item active">
                     <a class="nav-link" href="index.php">Home</a>
                   </li>
                 </ul>
               </div>
               <div class="mx-auto order-0">
                 <a class="navbar-brand mx-auto" href="index.php">SHOP AUTOMOBILI ONLINE</a>
                 <button class="navbar-toggler" type="button" data-toggle="collapse" data-target=".dual-collapse2">
                   <span class="navbar-toggler-icon"></span>
                 </button>
               </div>
               <div class="navbar-collapse collapse w-100 order-3 dual-collapse2">
                 <ul class="navbar-nav ms-auto">
                   <li class="nav-item">
                     <a class="nav-link" href="Admin/index.php">Admin</a>
                   </li>
                   </li>
                 </ul>
               </div>
             </div>
           </nav>

            <br><br>
            <div align="center">
               <div class="card" style="width: 30rem;">
                  <img class="card-img-top" src="images/github.jpg" alt="Card image cap">
                  <div class="card-body">
                     <h5 class="card-title">CREDITI LAVORO:</h5>
                     <p class="card-text">Il progetto è completamente accessibile via GitHub, per modifiche o per la visione</p>
                     <a href="https://github.com/ferrar65" class="btn btn-primary">LINK GITHUB</a>
                  </div>
               </div>
            </div>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>
         </body>
      </html>
