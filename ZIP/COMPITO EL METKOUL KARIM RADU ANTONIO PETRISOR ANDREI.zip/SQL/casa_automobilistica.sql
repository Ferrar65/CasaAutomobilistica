-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Creato il: Mag 26, 2021 alle 02:04
-- Versione del server: 10.4.19-MariaDB
-- Versione PHP: 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `societa`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `casa_automobilistica`
--

CREATE TABLE `casa_automobilistica` (
  `nomeCasa` varchar(30) NOT NULL,
  `annoFondazione` year(4) NOT NULL,
  `nomeFondatore` varchar(30) NOT NULL,
  `nazionalita` enum('afghana','albanese','algerina','andorrana','angolana','argentina','armena','australiana','austriaca','azera','bahamense','bahreinita','barbadiana','belga','bengalese','beninese','bhutanese','bielorussa','birmana','boliviana','bosniaca','botswana','brasiliana','britannica','bruneiana','bulgara','burkinabÃ©','burundese','cambogiana','camerunense','canadese','capoverdiana','ceca','centrafricana','ciadiana','cilena','cinese','cingalese','cipriota','colombiana','comoriana','congolese','costaricana','croata','cubana','danese','dominicana','ecuadoregna','egiziana','emiratina','eritrea','estone','etiope','figiana','filippina','finlandese','francese','gabonese','gambiana','georgiana','ghanese','giamaicana','giapponese','gibutiana','giordana','greca','grenadina','guatemalteca','guineana','guyanese','haitiana','honduregna','indiana','indonesiana','	irachena','iraniana','irlandese','islandese','israeliana','italiana','ivoriana','	kazka','	keniana','kirgisa','	kosovara','kuatiana','laotiana','lesothiana','lettone','libanese','liberiana','libica','liechtensteiniana','lituana','lussemburghese','macedone','malawiana','maldiviana','malesiana','malgascia','maliana','maltese','marocchina','marshallese','mauritana','mauriziana','messicana','micronesiana','moldava','monegasca','mongola','montenegrina','mozambicana','namibiana','nauruana','neozelandese','nepalese','nigeriana','nigerina','nordcoreana','norvegese','olandese','	omanita','pachistana','palestinese','panamense','papuana','paraguaiana','peruviana','polacca','portoghese','qatariota','romena','ruandese','russa','salvadoregna','samoana','sanmarinese','saudita','senegalese','serba','sierraleonese','singaporiana','siriana','slovacca','slovena','somala','spagnola','statunitense','sudafricana','sudanese','sudcoreana','svedese','svizzera','tagika','tailandese','taiwanese','tanzaniana','tedesca','togolese','tongana','tunisina','turca','turkmena','ucraina','ugandese','ungherese','uruguaiana','uzbeka','vanuatuana','vaticana','venezuelana','vietnamita','	yemenita','zambese','zimbabwese') NOT NULL,
  `mail` varchar(30) NOT NULL,
  `sitoWeb` varchar(30) NOT NULL,
  `descrizione` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dump dei dati per la tabella `casa_automobilistica`
--

INSERT INTO `casa_automobilistica` (`nomeCasa`, `annoFondazione`, `nomeFondatore`, `nazionalita`, `mail`, `sitoWeb`, `descrizione`) VALUES
('Bentley', 1919, 'Walter Owen Bentley', 'britannica', 'info@bentley.com', 'bentley.com', 'La Bentley è una storica azienda automobilistica britannica di autovetture di prestigio fondata nel 1919 da Walter Owen Bentley a Cricklewood, nei dintorni di Londra, nonché uno dei principali fornitori della Casa Reale inglese e vincitrice della 24 Ore di Le Mans nel 1924, 1927, 1928, 1929, 1930 e 2003.'),
('Chevrolet', 1911, 'Louis Chevrolet', 'statunitense', 'info@chevrolet.com', 'chevrolet.com', 'L\'azienda viene fondata nel Michigan nel 1911 da Louis Chevrolet, pilota svizzero, e da William C. Durant, fondatore della General Motors dalla quale era stato estromesso a causa dei debiti. '),
('Ford', 1903, 'Henry Ford', 'statunitense', 'info@ford.com', 'ford.com', 'Ford Motor Company è una casa automobilistica statunitense, fondata da Henry Ford a Dearborn nel 1903. È nota per aver utilizzato per la prima volta la catena di montaggio e il nastro trasportatore, in seguito adottati da numerose altre aziende e tuttora usati nelle industrie moderne. '),
('Lamborghini', 1963, 'Ferruccio Lamborghini', 'italiana', 'info@lamborghini.com', 'lamborghini.com', 'Ferruccio Lamborghini , un magnate manifatturiero italiano , ha fondato Automobili Ferruccio Lamborghini SpA nel 1963 per competere con marchi affermati, tra cui Ferrari . L\'azienda è stata notata per l\'utilizzo di un motore posteriore centrale, layout di trazione posteriore . Lamborghini è cresciuta rapidamente durante il suo primo decennio, ma le vendite sono crollate sulla scia della crisi finanziaria mondiale del 1973 e della crisi petrolifera'),
('Maserati', 1914, 'Alfieri Maserati', 'italiana', 'info@maserati.com', 'maserati.com', 'Maserati è un\'azienda italiana produttrice di automobili sportive di lusso fondata a Bologna, oggi con sede a Modena e per lungo tempo impegnata in differenti categorie automobilistiche grazie alla propria Squadra Corse.'),
('Mercedes-Benz', 1926, 'Karl Benz', 'tedesca', 'info@mercedes-benz.it', 'mercedes-benz.it', 'Mercedes-Benz, comunemente chiamata Mercedes, è sia un marchio automobilistico tedesco che, dalla fine del 2019 in poi, una sussidiaria - come Mercedes-Benz AG - di Daimler AG. Mercedes-Benz è nota per la produzione di veicoli di lusso e veicoli commerciali.'),
('Nissan', 1933, 'Yoshisuke Aikawa', 'giapponese', 'info@nissan.it', 'nissan.it', 'La Nissan Motor Corporation, Ltd. abbreviato in Nissan, è una casa automobilistica multinazionale giapponese con sede a Nishi-ku, Yokohama. L\'azienda è presente sul mercato automobilistico con i marchi Nissan, Infiniti e Datsun.'),
('Porsche', 1931, 'Ferdinand Porsche', 'tedesca', 'info@porsche.com', 'porsche.com', 'Porsche è una casa automobilistica tedesca con sede presso il quartiere Zuffenhausen della città di Stoccarda. Il capitale sociale dal 2012 è interamente posseduto da Volkswagen.'),
('Subaru', 1953, 'Kenji Kita', 'giapponese', 'info@subaru.com', 'subaru.com', 'Subaru è la parola giapponese per l\'ammasso stellare delle Pleiadi che sono anche raffigurate nel logo della compagnia. Le Pleiadi, note anche come \"Le sette sorelle\", conglobano sette stelle principali dell\'ammasso visibili a occhio nudo.\r\nLe stelle del marchio Subaru sono solo sei (una grande e cinque piccole), e rappresentano le cinque aziende che dopo la seconda guerra mondiale si unirono per formare un\'unica grande compagnia.'),
('Tesla', 2003, 'Elon Musk', 'statunitense', 'info@tesla.com', 'tesla.com', 'Tesla, Inc. è una società americana di veicoli elettrici e di energia pulita con sede a Palo Alto, in California. I prodotti attuali di Tesla includono auto elettriche, accumulo di energia della batteria dalla casa alla rete, pannelli solari e tegole solari, nonché altri prodotti e servizi correlati.');

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `casa_automobilistica`
--
ALTER TABLE `casa_automobilistica`
  ADD PRIMARY KEY (`nomeCasa`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
